/**
 * 🌌 MorphVerse Core
 * 
 * The ultimate generative avatar library.
 * Create beautiful, unique avatars with code.
 * 
 * @package @morphverse/core
 * @version 1.0.0
 * @license MIT
 */

const DNAGenerator = require('./dna/generator');
const SVGRenderer = require('./render/svg');

class MorphVerse {
  /**
   * Generate a complete avatar
   * 
   * @example
   * const avatar = MorphVerse.generate({
   *   seed: 'myuser',
   *   style: 'mandala',
   *   colorScheme: 'cosmic',
   *   size: 400
   * });
   * 
   * console.log(avatar.dna);  // DNA data
   * console.log(avatar.svg);  // SVG string
   */
  static generate(options = {}) {
    const {
      seed = Math.random().toString(36).substring(7),
      style = 'mandala',
      colorScheme = 'cosmic',
      size = 400,
      showGlow = true,
      showParticles = true,
    } = options;
    
    // Generate DNA
    const dna = DNAGenerator.generate(seed);
    
    // Render SVG
    const svg = SVGRenderer.render(dna, {
      size,
      style,
      colorScheme,
      showGlow,
      showParticles,
    });
    
    return {
      dna,
      svg,
      metadata: {
        version: '1.0.0',
        generatedAt: new Date().toISOString(),
        generator: 'MorphVerse Core',
      },
    };
  }
  
  /**
   * Generate DNA only (no rendering)
   */
  static generateDNA(seed) {
    return DNAGenerator.generate(seed);
  }
  
  /**
   * Generate multiple avatars
   */
  static generateBatch(count, options = {}) {
    const avatars = [];
    for (let i = 0; i < count; i++) {
      const seed = options.seed 
        ? `${options.seed}_${i}` 
        : `morph_${i}_${Date.now()}`;
      avatars.push(this.generate({ ...options, seed }));
    }
    return avatars;
  }
  
  /**
   * Get library version
   */
  static get version() {
    return '1.0.0';
  }
}

module.exports = MorphVerse;
