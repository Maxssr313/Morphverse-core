//═══════════════════════════════════════════════════
// MORPHVERSE SVG RENDERER
//═══════════════════════════════════════════════════

const { COLOR_SCHEMES } = require('../data/constants');

class SVGRenderer {
  /**
   * Render avatar DNA to SVG
   */
  static render(dna, options = {}) {
    const {
      size = 400,
      style = 'mandala',
      colorScheme = 'cosmic',
      background = '#000010',
      showGlow = true,
      showParticles = true,
    } = options;
    
    const cx = size / 2;
    const cy = size / 2;
    const colors = COLOR_SCHEMES[colorScheme] || COLOR_SCHEMES.cosmic;
    
    let svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${size} ${size}" width="${size}" height="${size}">`;
    
    // Background
    svg += `<rect width="${size}" height="${size}" fill="${background}"/>`;
    
    // Definitions
    if (showGlow) {
      svg += this._glowFilter();
    }
    
    // Background glow
    svg += this._backgroundGlow(cx, cy, size, dna);
    
    // Main pattern
    switch (style) {
      case 'mandala':
        svg += this._drawMandala(cx, cy, size, dna, colors);
        break;
      case 'sacred_geometry':
        svg += this._drawSacredGeometry(cx, cy, size, dna, colors);
        break;
      case 'crystal_lattice':
        svg += this._drawCrystalLattice(cx, cy, size, dna, colors);
        break;
      case 'quantum_field':
        svg += this._drawQuantumField(cx, cy, size, dna, colors);
        break;
      default:
        svg += this._drawMandala(cx, cy, size, dna, colors);
    }
    
    // Particles
    if (showParticles) {
      svg += this._drawParticles(cx, cy, size, dna);
    }
    
    // Center
    svg += this._drawCenter(cx, cy, size, dna, colors);
    
    svg += '</svg>';
    return svg;
  }
  
  static _glowFilter() {
    return `<defs>
      <filter id="glow">
        <feGaussianBlur stdDeviation="3" result="blur"/>
        <feMerge>
          <feMergeNode in="blur"/>
          <feMergeNode in="SourceGraphic"/>
        </feMerge>
      </filter>
      <filter id="softGlow">
        <feGaussianBlur stdDeviation="1.5" result="blur"/>
        <feMerge>
          <feMergeNode in="blur"/>
          <feMergeNode in="SourceGraphic"/>
        </feMerge>
      </filter>
    </defs>`;
  }
  
  static _backgroundGlow(cx, cy, size, dna) {
    const r = size * 0.4;
    return `<circle cx="${cx}" cy="${cy}" r="${r}" fill="${dna.rarity.color}" opacity="0.08" filter="url(#glow)"/>`;
  }
  
  static _drawMandala(cx, cy, size, dna, colors) {
    let svg = '';
    const rings = dna.rings || 3;
    
    for (let ring = 0; ring < rings; ring++) {
      const radius = size * (0.1 + ring * 0.35 / rings);
      const petals = dna.symmetry + ring * 2;
      
      for (let p = 0; p < petals; p++) {
        const angle = (p / petals) * Math.PI * 2;
        const x = cx + Math.cos(angle) * radius;
        const y = cy + Math.sin(angle) * radius;
        const petalSize = size * 0.02 * (1 - ring * 0.15);
        
        const colorIndex = (ring + p) % colors.length;
        const color = colors[colorIndex];
        
        svg += `<circle cx="${x.toFixed(0)}" cy="${y.toFixed(0)}" r="${petalSize.toFixed(0)}" fill="${color}" opacity="0.7" filter="url(#softGlow)"/>`;
      }
    }
    return svg;
  }
  
  static _drawSacredGeometry(cx, cy, size, dna, colors) {
    let svg = '';
    const rings = dna.rings || 4;
    
    for (let ring = 0; ring < rings; ring++) {
      const radius = size * (0.08 + ring * 0.25 / rings);
      const petals = dna.symmetry;
      
      for (let p = 0; p < petals; p++) {
        const angle = (p / petals) * Math.PI * 2;
        const x = cx + Math.cos(angle) * radius;
        const y = cy + Math.sin(angle) * radius;
        
        svg += `<circle cx="${x.toFixed(0)}" cy="${y.toFixed(0)}" r="${radius.toFixed(0)}" fill="none" stroke="${colors[ring % colors.length]}" stroke-width="1" opacity="0.4"/>`;
      }
    }
    return svg;
  }
  
  static _drawCrystalLattice(cx, cy, size, dna, colors) {
    let svg = '';
    const points = [];
    const count = dna.symmetry + 4;
    
    for (let i = 0; i < count; i++) {
      const phi = Math.acos(1 - 2 * (i + 0.5) / count);
      const theta = Math.PI * (1 + Math.sqrt(5)) * i;
      const r = size * 0.35;
      
      const x = cx + Math.sin(phi) * Math.cos(theta) * r;
      const y = cy + Math.sin(phi) * Math.sin(theta) * r;
      points.push({ x, y });
      
      svg += `<circle cx="${x.toFixed(0)}" cy="${y.toFixed(0)}" r="${size*0.02}" fill="${colors[i % colors.length]}" filter="url(#glow)"/>`;
    }
    
    // Connect nearby points
    for (let i = 0; i < points.length; i++) {
      for (let j = i + 1; j < points.length; j++) {
        const dx = points[i].x - points[j].x;
        const dy = points[i].y - points[j].y;
        const dist = Math.sqrt(dx*dx + dy*dy);
        if (dist < size * 0.4) {
          svg += `<line x1="${points[i].x.toFixed(0)}" y1="${points[i].y.toFixed(0)}" x2="${points[j].x.toFixed(0)}" y2="${points[j].y.toFixed(0)}" stroke="${colors[0]}" stroke-width="0.5" opacity="0.3"/>`;
        }
      }
    }
    return svg;
  }
  
  static _drawQuantumField(cx, cy, size, dna, colors) {
    let svg = '';
    const count = 50 + dna.particles * 5;
    
    for (let i = 0; i < count; i++) {
      const angle = (i / count) * Math.PI * 8;
      const r = size * 0.1 + Math.sin(i * 0.3) * size * 0.3;
      const x = cx + Math.cos(angle) * r;
      const y = cy + Math.sin(angle) * r;
      const s = Math.max(0.5, 2 - (i % 3));
      
      svg += `<circle cx="${x.toFixed(0)}" cy="${y.toFixed(0)}" r="${s}" fill="${colors[i % colors.length]}" opacity="${0.3 + (i/count)*0.5}" filter="url(#softGlow)"/>`;
    }
    return svg;
  }
  
  static _drawParticles(cx, cy, size, dna) {
    let svg = '';
    const count = dna.particles || 8;
    
    for (let i = 0; i < count; i++) {
      const angle = (i / count) * Math.PI * 2;
      const r = size * 0.4;
      const x = cx + Math.cos(angle) * r;
      const y = cy + Math.sin(angle) * r;
      
      svg += `<circle cx="${x.toFixed(0)}" cy="${y.toFixed(0)}" r="${size*0.01}" fill="white" opacity="0.8" filter="url(#glow)"/>`;
    }
    return svg;
  }
  
  static _drawCenter(cx, cy, size, dna, colors) {
    return `
      <circle cx="${cx}" cy="${cy}" r="${size*0.05}" fill="${colors[0]}" opacity="0.9" filter="url(#glow)"/>
      <circle cx="${cx}" cy="${cy}" r="${size*0.025}" fill="white" filter="url(#glow)"/>
      <text x="${cx}" y="${cy+size*0.008}" text-anchor="middle" fill="white" font-size="${size*0.04}" font-family="sans-serif" font-weight="bold" filter="url(#glow)">${dna.symbol}</text>
    `;
  }
}

module.exports = SVGRenderer;
