//═══════════════════════════════════════════════════
// MORPHVERSE DNA GENERATOR
// The heart of the system
//═══════════════════════════════════════════════════

const { RARITIES, ELEMENTS, SYMBOLS, ANIMATIONS } = require('../data/constants');

class DNAGenerator {
  /**
   * Generate unique avatar DNA from a seed
   * @param {string} seed - Any string (username, email, random)
   * @returns {object} Complete avatar DNA
   */
  static generate(seed) {
    const hash = this._hash(seed);
    const rarity = this._rollRarity(hash);
    
    return {
      // Identity
      seed,
      id: this._generateId(seed),
      
      // Core traits
      rarity: RARITIES[rarity],
      element: this._pickElement(hash),
      symbol: this._pickSymbol(hash),
      
      // Visual traits
      symmetry: 4 + (hash[2] % 9),
      complexity: (hash[3] % 100) / 100,
      hue: (hash[4] % 360) / 360,
      aura: 0.3 + (hash[5] % 70) / 100,
      particles: 3 + (hash[6] % 15),
      rings: 2 + (hash[7] % 5),
      
      // Animation
      animation: ANIMATIONS[hash[8] % ANIMATIONS.length],
      animationSpeed: 0.5 + (hash[9] % 100) / 100,
      
      // Metadata
      generation: 1,
      createdAt: new Date().toISOString(),
      attributes: this._generateAttributes(hash),
    };
  }
  
  /**
   * Create a simple hash from any string
   */
  static _hash(str) {
    const bytes = [];
    for (let i = 0; i < 16; i++) {
      let val = 0;
      for (let j = 0; j < str.length; j++) {
        val = ((val << 3) - val + str.charCodeAt((i + j) % str.length)) & 0xFF;
      }
      bytes.push(Math.abs(val));
    }
    return bytes;
  }
  
  /**
   * Weighted random rarity roll
   */
  static _rollRarity(hash) {
    const roll = hash[0] % 100;
    let cumulative = 0;
    
    for (const [key, data] of Object.entries(RARITIES)) {
      cumulative += data.weight;
      if (roll < cumulative) return key;
    }
    return 'COMMON';
  }
  
  /**
   * Pick element from hash
   */
  static _pickElement(hash) {
    const elems = Object.values(ELEMENTS);
    return elems[hash[1] % elems.length];
  }
  
  /**
   * Pick symbol from hash
   */
  static _pickSymbol(hash) {
    return SYMBOLS[hash[2] % SYMBOLS.length];
  }
  
  /**
   * Generate unique ID from seed
   */
  static _generateId(seed) {
    let h = 0;
    for (let i = 0; i < seed.length; i++) {
      h = ((h << 5) - h) + seed.charCodeAt(i);
      h |= 0;
    }
    return 'mvx_' + Math.abs(h).toString(36).padStart(8, '0');
  }
  
  /**
   * Generate OpenSea-compatible attributes
   */
  static _generateAttributes(hash) {
    const attributes = [
      { trait_type: 'Generation', value: 1 },
      { trait_type: 'Symmetry', display_type: 'number', value: 4 + (hash[2] % 9) },
      { trait_type: 'Complexity', display_type: 'number', value: Math.round(((hash[3] % 100) / 100) * 100) },
      { trait_type: 'Aura', display_type: 'boost_percentage', value: 30 + (hash[5] % 70) },
      { trait_type: 'Particles', display_type: 'number', value: 3 + (hash[6] % 15) },
    ];
    return attributes;
  }
  
  /**
   * Generate multiple avatars at once
   */
  static generateBatch(count, baseSeed = 'morphverse') {
    const avatars = [];
    for (let i = 0; i < count; i++) {
      avatars.push(this.generate(`${baseSeed}_${i}`));
    }
    return avatars;
  }
}

module.exports = DNAGenerator;
