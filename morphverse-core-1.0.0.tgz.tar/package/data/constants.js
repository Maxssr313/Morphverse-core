//═══════════════════════════════════════════════════
// MORPHVERSE CONSTANTS
//═══════════════════════════════════════════════════

const RARITIES = {
  MYTHIC:    { level: 5, name: 'Mythic',    weight: 1,  price: 1.0,  color: '#ff44aa', emoji: '💎' },
  LEGENDARY: { level: 4, name: 'Legendary', weight: 4,  price: 0.5,  color: '#ffaa00', emoji: '👑' },
  EPIC:      { level: 3, name: 'Epic',      weight: 8,  price: 0.1,  color: '#aa44ff', emoji: '🔮' },
  RARE:      { level: 2, name: 'Rare',      weight: 12, price: 0.05, color: '#4488ff', emoji: '💫' },
  UNCOMMON:  { level: 1, name: 'Uncommon',  weight: 25, price: 0.01, color: '#44aa44', emoji: '✨' },
  COMMON:    { level: 0, name: 'Common',    weight: 50, price: 0.005,color: '#888888', emoji: '⭐' },
};

const ELEMENTS = [
  { name: 'Cosmic',  emoji: '🌌', color: '#8844ff', trait: 'Mysterious' },
  { name: 'Crystal', emoji: '💎', color: '#44ffff', trait: 'Pure' },
  { name: 'Flame',   emoji: '🔥', color: '#ff4444', trait: 'Passionate' },
  { name: 'Ocean',   emoji: '🌊', color: '#4488ff', trait: 'Deep' },
  { name: 'Shadow',  emoji: '🌑', color: '#222244', trait: 'Secretive' },
  { name: 'Light',   emoji: '☀️', color: '#ffff44', trait: 'Radiant' },
  { name: 'Void',    emoji: '🕳️', color: '#000011', trait: 'Empty' },
  { name: 'Quantum', emoji: '⚛️', color: '#ff88ff', trait: 'Uncertain' },
];

const SYMBOLS = ['✦', '⬡', '◆', '◈', '✧', '❋', '⚝', '⛧', '◉', '◎', '⬢', '◈'];

const ANIMATIONS = ['breathe', 'spin', 'pulse', 'orbit', 'shimmer', 'flow', 'morph', 'glitch'];

const STYLES = [
  'mandala', 'sacred_geometry', 'crystal_lattice', 'quantum_field',
  'plasma_flow', 'dark_matter', 'nebula_bloom', 'void_weave',
  'bioluminescent', 'geometric_bloom',
];

const COLOR_SCHEMES = {
  cosmic:    ['#1a0a2e', '#16213e', '#0f3460', '#e94560', '#f5f5f5'],
  sunset:    ['#ff6b6b', '#ffa07a', '#ffd700', '#ff8c00', '#ff1493'],
  ocean:     ['#006994', '#003d5c', '#00b4d8', '#90e0ef', '#caf0f8'],
  neon:      ['#ff006e', '#8338ec', '#3a86ff', '#00f5d4', '#fee440'],
  forest:    ['#1b4332', '#2d6a4f', '#40916c', '#52b788', '#95d5b2'],
  cyber:     ['#000000', '#00ff00', '#00ffff', '#ff00ff', '#ffff00'],
  royal:     ['#2b0f4c', '#5b1a7a', '#8b2fc9', '#c77dff', '#e0aaff'],
};

if (typeof module !== 'undefined') {
  module.exports = { RARITIES, ELEMENTS, SYMBOLS, ANIMATIONS, STYLES, COLOR_SCHEMES };
}
